# Ascendix Django Core Package
